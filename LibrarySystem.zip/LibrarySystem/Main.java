import model.*;
import service.Library;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\n=============================================");
            System.out.println("📚  Welcome to the Library Management System");
            System.out.println("=============================================");
            System.out.println("1.  ➕ Add Book");
            System.out.println("2.  👤 Register Student");
            System.out.println("3.  🧑‍💼 Register Librarian");
            System.out.println("4.  📚 Show All Books");
            System.out.println("5.  🔍 Search Book by Title/Author");
            System.out.println("6.  📥 Issue Book");
            System.out.println("7.  📤 Return Book");
            System.out.println("8.  ⏰ Show Overdue Books");
            System.out.println("9.  📋 View Borrowed Books of User");
            System.out.println("10. 🗑️  Remove Book");
            System.out.println("11. 📃 List All Registered Students");
            System.out.println("0.  ❌ Exit");
            System.out.print("\n👉 Enter your choice: ");

            String input = scanner.nextLine();
            System.out.println(); // Add a line break for clean UI

            switch (input) {
                case "1" -> {
                    System.out.println("➕ Add New Book");
                    System.out.print("📘 Title       : ");
                    String title = scanner.nextLine();
                    System.out.print("✍️  Author     : ");
                    String author = scanner.nextLine();
                    System.out.print("🔢 ISBN       : ");
                    String isbn = scanner.nextLine();
                    library.addBook(new Book(title, author, isbn));
                }
                case "2" -> {
                    System.out.println("👤 Register Student");
                    System.out.print("👤 Name        : ");
                    String name = scanner.nextLine();
                    System.out.print("🆔 Student ID  : ");
                    String id = scanner.nextLine();
                    library.registerUser(new Student(id, name));
                }
                case "3" -> {
                    System.out.println("🧑‍💼 Register Librarian");
                    System.out.print("👤 Name        : ");
                    String name = scanner.nextLine();
                    System.out.print("🆔 Librarian ID: ");
                    String id = scanner.nextLine();
                    library.registerUser(new Librarian(id, name));
                }
                case "4" -> {
                    System.out.println("📚 All Available Books:");
                    library.showBooks();
                }
                case "5" -> {
                    System.out.println("🔍 Search Book");
                    System.out.print("🔎 Enter keyword (title/author): ");
                    String keyword = scanner.nextLine();
                    library.searchBooks(keyword);
                }
                case "6" -> {
                    System.out.println("📥 Issue Book");
                    System.out.print("🔢 ISBN        : ");
                    String isbn = scanner.nextLine();
                    System.out.print("🆔 User ID     : ");
                    String userId = scanner.nextLine();
                    library.issueBook(isbn, userId);
                }
                case "7" -> {
                    System.out.println("📤 Return Book");
                    System.out.print("🔢 ISBN to return: ");
                    String isbn = scanner.nextLine();
                    library.returnBook(isbn);
                }
                case "8" -> {
                    System.out.println("⏰ Overdue Books:");
                    library.listOverdueBooks();
                }
                case "9" -> {
                    System.out.println("📋 View Borrowed Books");
                    System.out.print("🆔 Enter User ID: ");
                    String userId = scanner.nextLine();
                    library.listBorrowedBooks(userId);
                }
                case "10" -> {
                    System.out.println("🗑️ Remove Book");
                    System.out.print("🔢 Enter ISBN to remove: ");
                    String isbn = scanner.nextLine();
                    library.removeBook(isbn);
                }
                case "11" -> {
                    System.out.println("📃 Registered Students:");
                    library.listAllStudents();
                }
                case "0" -> {
                    System.out.println("✅ Saving data...");
                    System.out.println("👋 Goodbye! See you again.");
                    exit = true;
                }
                default -> {
                    System.out.println("❌ Invalid choice. Please try again!");
                }
            }

            System.out.println("\n---------------------------------------------");
        }

        scanner.close();
    }
}
