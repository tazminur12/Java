package service;

import model.*;

import java.util.ArrayList;
import java.util.List;

public class Library {
    private final ArrayList<Book> books;
    private final ArrayList<User> users;

    private final String BOOK_FILE = "books.dat";
    private final String USER_FILE = "users.dat";

    public Library() {
        books = LibraryUtils.loadData(BOOK_FILE);
        users = LibraryUtils.loadData(USER_FILE);
    }

    // -------- BOOK METHODS --------
    public void addBook(Book book) {
        if (findBookByIsbn(book.getIsbn()) != null) {
            System.out.println("⚠️ Book with same ISBN already exists.");
            return;
        }
        books.add(book);
        saveAll();
        System.out.println("✅ Book added.");
    }

    public void removeBook(String isbn) {
        Book book = findBookByIsbn(isbn);
        if (book == null) {
            System.out.println("❌ Book not found.");
        } else if (!book.isAvailable()) {
            System.out.println("⚠️ Book is currently issued and cannot be removed.");
        } else {
            books.remove(book);
            saveAll();
            System.out.println("🗑️ Book removed successfully.");
        }
    }

    public void showBooks() {
        if (books.isEmpty()) System.out.println("No books in library.");
        else books.forEach(System.out::println);
    }

    public void searchBooks(String keyword) {
        boolean found = false;
        for (Book b : books) {
            if (b.getTitle().toLowerCase().contains(keyword.toLowerCase()) ||
                b.getAuthor().toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println(b);
                found = true;
            }
        }
        if (!found) System.out.println("❌ No matching books found.");
    }

    public void issueBook(String isbn, String userId) {
        Book book = findBookByIsbn(isbn);
        User user = findUserById(userId);

        if (book == null) {
            System.out.println("❌ Book not found.");
        } else if (!book.isAvailable()) {
            System.out.println("❌ Book already issued.");
        } else if (user == null) {
            System.out.println("❌ User not found.");
        } else {
            book.borrow(userId);
            user.borrowBook(isbn);
            saveAll();
            System.out.println("✅ Book issued. Due in 7 days.");
        }
    }

    public void returnBook(String isbn) {
        Book book = findBookByIsbn(isbn);
        if (book == null || book.isAvailable()) {
            System.out.println("❌ Invalid return.");
            return;
        }

        User user = findUserById(book.getBorrowerId());
        if (user != null) user.returnBook(isbn);

        boolean late = book.isOverdue();
        book.returnBook();
        saveAll();

        if (late)
            System.out.println("⚠️ Book returned late! Fine may apply.");
        else
            System.out.println("✅ Book returned successfully.");
    }

    public void listOverdueBooks() {
        boolean any = false;
        for (Book b : books) {
            if (b.isOverdue()) {
                System.out.println("⏰ " + b);
                any = true;
            }
        }
        if (!any) System.out.println("✅ No overdue books.");
    }

    // -------- USER METHODS --------
    public void registerUser(User user) {
        if (findUserById(user.getId()) != null) {
            System.out.println("⚠️ User with this ID already exists.");
            return;
        }
        users.add(user);
        saveAll();
        System.out.println("✅ User registered.");
    }

    public void listBorrowedBooks(String userId) {
        User user = findUserById(userId);
        if (user == null) {
            System.out.println("❌ User not found.");
            return;
        }

        List<String> borrowed = user.getBorrowedBooks();
        if (borrowed.isEmpty()) {
            System.out.println("ℹ️ No books borrowed by " + user.getName());
        } else {
            System.out.println("📖 Books borrowed by " + user.getName() + ":");
            for (String isbn : borrowed) {
                Book b = findBookByIsbn(isbn);
                if (b != null) System.out.println(" - " + b);
            }
        }
    }

    public void listAllStudents() {
        boolean found = false;
        for (User user : users) {
            if (user instanceof Student) {
                System.out.println(user);
                found = true;
            }
        }
        if (!found) {
            System.out.println("ℹ️ No students registered.");
        }
    }

    // -------- HELPER METHODS --------
    private Book findBookByIsbn(String isbn) {
        for (Book b : books)
            if (b.getIsbn().equalsIgnoreCase(isbn)) return b;
        return null;
    }

    private User findUserById(String id) {
        for (User u : users)
            if (u.getId().equalsIgnoreCase(id)) return u;
        return null;
    }

    private void saveAll() {
        LibraryUtils.saveData(BOOK_FILE, books);
        LibraryUtils.saveData(USER_FILE, users);
    }
}
