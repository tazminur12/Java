package service;

import java.io.*;
import java.util.ArrayList;

public class LibraryUtils {
    public static <T> void saveData(String filename, ArrayList<T> data) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(data);
        } catch (IOException e) {
            System.out.println("❌ Error saving data: " + e.getMessage());
        }
    }

    public static <T> ArrayList<T> loadData(String filename) {
        File file = new File(filename);
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            return (ArrayList<T>) ois.readObject();
        } catch (Exception e) {
            System.out.println("⚠️ Error loading data: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
