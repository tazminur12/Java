package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public abstract class User implements Serializable {
    protected String id, name;
    protected List<String> borrowedIsbns = new ArrayList<>();

    public User(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public abstract String getRole();

    public void borrowBook(String isbn) {
        borrowedIsbns.add(isbn);
    }

    public void returnBook(String isbn) {
        borrowedIsbns.remove(isbn);
    }

    public List<String> getBorrowedBooks() {
        return borrowedIsbns;
    }

    public String getId() { return id; }
    public String getName() { return name; }

    @Override
    public String toString() {
        return name + " (" + getRole() + ") | ID: " + id;
    }
}
