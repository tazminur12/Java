package model;

import java.io.Serializable;
import java.time.LocalDate;

public class Book implements Serializable {
    private String title, author, isbn;
    private boolean isAvailable = true;
    private LocalDate dueDate;
    private String borrowerId;

    public Book(String title, String author, String isbn) {
        this.title = title; this.author = author; this.isbn = isbn;
    }

    public void borrow(String userId) {
        isAvailable = false;
        borrowerId = userId;
        dueDate = LocalDate.now().plusDays(7);
    }

    public void returnBook() {
        isAvailable = true;
        borrowerId = null;
        dueDate = null;
    }

    public boolean isAvailable() { return isAvailable; }
    public String getBorrowerId() { return borrowerId; }
    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public LocalDate getDueDate() { return dueDate; }

    public boolean isOverdue() {
        return !isAvailable && LocalDate.now().isAfter(dueDate);
    }

    @Override
    public String toString() {
        return title + " by " + author + " | ISBN: " + isbn +
               (isAvailable ? " | Available" : " | Issued to " + borrowerId + " | Due: " + dueDate);
    }
}
